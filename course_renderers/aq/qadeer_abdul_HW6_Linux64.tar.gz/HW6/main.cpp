/**
 * Main entry point
 * USC csci 580 *
*/

#include "Application6.h"

int main(int argc, const char * argv[])
{
  Application6 application;

  application.runAntiAliasingRenderer();
  
  return 0;
}

